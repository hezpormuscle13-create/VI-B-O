package com.hezpor.otgmapper

import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import java.util.concurrent.Executors

/**
 * Quản lý nhiều "ngón tay" ảo cùng lúc (mỗi ngón có 1 id) và đẩy MotionEvent
 * đa điểm vào hệ thống theo đúng thứ tự trên 1 luồng riêng.
 */
class TouchInjector {
    private val io = Executors.newSingleThreadExecutor()
    private val ids = ArrayList<Int>()
    private val xs = HashMap<Int, Float>()
    private val ys = HashMap<Int, Float>()
    private var downTime = 0L

    @Synchronized
    fun down(id: Int, x: Float, y: Float) {
        if (id in ids) { move(id, x, y); return }
        val first = ids.isEmpty()
        if (first) downTime = SystemClock.uptimeMillis()
        ids.add(id); xs[id] = x; ys[id] = y
        val action = if (first) MotionEvent.ACTION_DOWN
        else MotionEvent.ACTION_POINTER_DOWN or (ids.indexOf(id) shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        emit(action)
    }

    @Synchronized
    fun move(id: Int, x: Float, y: Float) {
        if (id !in ids) return
        xs[id] = x; ys[id] = y
        emit(MotionEvent.ACTION_MOVE)
    }

    @Synchronized
    fun up(id: Int) {
        val idx = ids.indexOf(id)
        if (idx < 0) return
        val action = if (ids.size == 1) MotionEvent.ACTION_UP
        else MotionEvent.ACTION_POINTER_UP or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        emit(action)
        ids.removeAt(idx); xs.remove(id); ys.remove(id)
    }

    @Synchronized
    fun upAll() {
        ids.toList().forEach { up(it) }
    }

    private fun emit(action: Int) {
        val n = ids.size
        val props = Array(n) {
            MotionEvent.PointerProperties().apply {
                id = ids[it]
                toolType = MotionEvent.TOOL_TYPE_FINGER
            }
        }
        val coords = Array(n) {
            MotionEvent.PointerCoords().apply {
                x = xs[ids[it]]!!
                y = ys[ids[it]]!!
                pressure = 1f
                size = 1f
            }
        }
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        io.execute {
            try { ShizukuInput.send(ev) } finally { ev.recycle() }
        }
    }
}

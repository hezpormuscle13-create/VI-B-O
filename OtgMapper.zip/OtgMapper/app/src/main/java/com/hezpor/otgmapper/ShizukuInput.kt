package com.hezpor.otgmapper

import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.view.InputEvent
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method

/**
 * Gửi MotionEvent vào hệ thống với quyền shell (qua Shizuku):
 * gọi IInputManager.injectInputEvent() bằng reflection.
 */
object ShizukuInput {
    private var im: Any? = null
    private var inject: Method? = null

    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun hasPermission(): Boolean = try {
        isRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun init(): Boolean {
        if (inject != null) return true
        if (!hasPermission()) return false
        return try {
            if (Build.VERSION.SDK_INT >= 28) HiddenApiBypass.addHiddenApiExemptions("L")
            val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            val service = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
            im = service
            inject = service.javaClass.getMethod(
                "injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType
            )
            true
        } catch (e: Throwable) {
            false
        }
    }

    /** mode 0 = INJECT_INPUT_EVENT_MODE_ASYNC */
    fun send(e: MotionEvent) {
        try { inject?.invoke(im, e, 0) } catch (t: Throwable) { /* bỏ qua sự kiện lỗi */ }
    }
}

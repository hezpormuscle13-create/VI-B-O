package com.hezpor.otgmapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
import android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
import android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
import android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * Bong bóng nổi trên mọi app (kể cả game). Chạm vào để mở menu:
 *  [Sửa nút] [Map: BẬT/TẮT] [Thoát]. Kéo bong bóng để di chuyển.
 */
class BubbleService : Service() {

    private lateinit var wm: WindowManager
    private val inj = TouchInjector()
    private var bubble: LinearLayout? = null
    private var menu: LinearLayout? = null
    private var mapBtn: TextView? = null
    private var input: InputOverlay? = null
    private var editor: EditorLayer? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()
        buildBubble()
    }

    override fun onDestroy() {
        setMapping(false)
        editor?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        inj.upAll()
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("bubble", "OTG Mapper", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "bubble")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("OTG Mapper")
            .setContentText("Bong bóng đang chạy")
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- tiện ích giao diện ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = r.toFloat()
    }

    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 13f
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = round(0xDD263238.toInt(), dp(16))
        layoutParams = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6) }
        setOnClickListener { onClick() }
    }

    // ---------- bong bóng ----------

    private fun buildBubble() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val b = TextView(this).apply {
            text = "🎮"
            textSize = 22f
            gravity = Gravity.CENTER
            background = round(0xCC1E88E5.toInt(), dp(24))
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }
        val m = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }
        m.addView(chip("Sửa nút") { openEditor() })
        val mb = chip("Map: TẮT") { setMapping(input == null) }
        mapBtn = mb
        m.addView(mb)
        m.addView(chip("Thoát") { stopSelf() })
        root.addView(b)
        root.addView(m)
        menu = m
        bubble = root

        val p = lp(WRAP_CONTENT, WRAP_CONTENT, FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_NO_LIMITS)
            .apply { x = 0; y = dp(120) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moved = true
                    if (moved) { p.x = ox + dx; p.y = oy + dy; wm.updateViewLayout(root, p) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    m.visibility = if (m.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                }
            }
            true
        }
        wm.addView(root, p)
    }

    // ---------- bật/tắt map ----------

    private fun setMapping(on: Boolean) {
        if (on) {
            if (input != null) return
            if (!ShizukuInput.init()) {
                toast("Hãy mở Shizuku và cấp quyền cho OTG Mapper")
                return
            }
            val profile = Store.load(this)
            val mapper = Mapper(inj, profile) { realSize(this) }
            val v = InputOverlay(this, mapper, profile.toggleKey)
            input = v
            // 1x1 px, nhận phím nhưng không chặn cảm ứng
            wm.addView(v, lp(1, 1, FLAG_NOT_TOUCHABLE or FLAG_LAYOUT_NO_LIMITS))
        } else {
            input?.let { it.shutdown(); runCatching { wm.removeView(it) } }
            input = null
        }
        mapBtn?.text = if (input != null) "Map: BẬT" else "Map: TẮT"
        mapBtn?.background = round(if (input != null) 0xDD2E7D32.toInt() else 0xDD263238.toInt(), dp(16))
    }

    // ---------- chỉnh nút ----------

    private fun openEditor() {
        if (editor != null) return
        setMapping(false)
        menu?.visibility = View.GONE
        bubble?.visibility = View.GONE
        val profile = Store.load(this)
        val e = EditorLayer(this, profile) { save ->
            if (save) Store.save(this, profile)
            editor?.let { runCatching { wm.removeView(it) } }
            editor = null
            bubble?.visibility = View.VISIBLE
        }
        val params = lp(MATCH_PARENT, MATCH_PARENT, FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS)
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        editor = e
        wm.addView(e, params)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

package com.hezpor.otgmapper

import android.content.Context
import android.util.DisplayMetrics
import android.view.KeyEvent
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject

// Mã "phím" ảo cho các nút chuột (lớn hơn mọi KEYCODE của Android)
const val MOUSE_LEFT = 10001
const val MOUSE_RIGHT = 10002
const val MOUSE_MIDDLE = 10003

enum class Kind { JOYSTICK, TAP, CAMERA }

/**
 * Một nút trên màn hình. x, y lưu theo tỉ lệ (0..1) của chiều rộng/cao màn hình,
 * r lưu theo tỉ lệ chiều cao -> profile dùng được ở mọi độ phân giải.
 */
class MapItem(var kind: Kind, var x: Float, var y: Float, var r: Float, var key: Int = -1) {
    fun toJson(): JSONObject = JSONObject()
        .put("k", kind.name).put("x", x.toDouble()).put("y", y.toDouble())
        .put("r", r.toDouble()).put("key", key)

    companion object {
        fun fromJson(o: JSONObject) = MapItem(
            Kind.valueOf(o.getString("k")),
            o.getDouble("x").toFloat(), o.getDouble("y").toFloat(),
            o.getDouble("r").toFloat(), o.optInt("key", -1)
        )
    }
}

class Profile(
    var items: MutableList<MapItem> = mutableListOf(),
    var sens: Float = 1.5f,
    var toggleKey: Int = KeyEvent.KEYCODE_F1
)

object Store {
    private const val PREFS = "otgmapper"

    fun defaultProfile() = Profile(
        mutableListOf(
            MapItem(Kind.JOYSTICK, 0.17f, 0.70f, 0.12f),
            MapItem(Kind.CAMERA, 0.75f, 0.45f, 0.15f),
            MapItem(Kind.TAP, 0.88f, 0.72f, 0.06f, MOUSE_LEFT)
        )
    )

    fun load(c: Context): Profile {
        val s = c.getSharedPreferences(PREFS, 0).getString("profile", null) ?: return defaultProfile()
        return try {
            val o = JSONObject(s)
            val arr = o.getJSONArray("items")
            val list = MutableList(arr.length()) { MapItem.fromJson(arr.getJSONObject(it)) }
            Profile(list, o.optDouble("sens", 1.5).toFloat(), o.optInt("toggle", KeyEvent.KEYCODE_F1))
        } catch (e: Exception) {
            defaultProfile()
        }
    }

    fun save(c: Context, p: Profile) {
        val arr = JSONArray()
        p.items.forEach { arr.put(it.toJson()) }
        val o = JSONObject().put("items", arr).put("sens", p.sens.toDouble()).put("toggle", p.toggleKey)
        c.getSharedPreferences(PREFS, 0).edit().putString("profile", o.toString()).apply()
    }
}

fun keyName(code: Int): String = when (code) {
    MOUSE_LEFT -> "Chuột T"
    MOUSE_RIGHT -> "Chuột P"
    MOUSE_MIDDLE -> "Chuột G"
    else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
}

/** Kích thước thật của màn hình hiện tại (tự đổi khi xoay ngang/dọc). */
@Suppress("DEPRECATION")
fun realSize(c: Context): IntArray {
    val dm = DisplayMetrics()
    (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
    return intArrayOf(dm.widthPixels, dm.heightPixels)
}

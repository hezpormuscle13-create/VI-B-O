package com.hezpor.otgmapper

import android.content.Context
import android.view.KeyEvent
import android.view.View
import android.widget.Toast

/**
 * Cửa sổ 1x1 px, có focus để nhận phím OTG + khóa con trỏ chuột (pointer capture),
 * nhưng không chặn cảm ứng nên game vẫn nhận chạm bình thường.
 * Phím bật/tắt (mặc định F1) để tạm dừng map và dùng chuột như bình thường.
 */
class InputOverlay(
    ctx: Context,
    private val mapper: Mapper,
    private val toggleKey: Int
) : View(ctx) {

    private var paused = false

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        setOnCapturedPointerListener { _, e ->
            mapper.mouse(e.x, e.y, e.buttonState)
            true
        }
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) {
            requestFocus()
            if (!paused) requestPointerCapture()
        } else {
            mapper.releaseAll()
        }
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == toggleKey) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) toggle()
            return true
        }
        if (paused) return super.dispatchKeyEvent(e)
        return mapper.key(e.keyCode, e.action == KeyEvent.ACTION_DOWN)
    }

    private fun toggle() {
        paused = !paused
        if (paused) {
            mapper.releaseAll()
            releasePointerCapture()
        } else {
            requestPointerCapture()
        }
        Toast.makeText(context, if (paused) "Map: TẠM DỪNG" else "Map: ĐANG CHẠY", Toast.LENGTH_SHORT).show()
    }

    fun shutdown() {
        mapper.releaseAll()
        releasePointerCapture()
    }
}

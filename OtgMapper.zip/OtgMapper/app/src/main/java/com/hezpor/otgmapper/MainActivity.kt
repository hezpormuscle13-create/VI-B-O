package com.hezpor.otgmapper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun btn(t: String, f: () -> Unit) {
            root.addView(Button(this).apply {
                text = t
                isAllCaps = false
                setOnClickListener { f() }
            })
        }
        root.addView(TextView(this).apply { text = "OTG Mapper"; textSize = 24f })
        status = TextView(this).apply { textSize = 15f; setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(status)

        btn("1. Cấp quyền hiển thị trên ứng dụng khác") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        btn("2. Cấp quyền Shizuku") { requestShizuku() }
        btn("3. Bật bong bóng nổi") { startBubble() }
        btn("Tắt bong bóng") { stopService(Intent(this, BubbleService::class.java)) }

        root.addView(TextView(this).apply {
            textSize = 14f
            setPadding(0, pad, 0, 0)
            text = "Cách dùng:\n" +
                "• Mở game, chạm bong bóng 🎮 → Sửa nút → kéo các nút tới đúng vị trí trên game → Lưu.\n" +
                "• Chạm bong bóng → Map: BẬT rồi chơi bằng phím/chuột OTG.\n" +
                "• Nhấn F1 để tạm dừng/tiếp tục map (hiện lại con trỏ chuột).\n" +
                "• Joystick dùng W A S D; chuột điều khiển camera."
        })
        setContentView(ScrollView(this).apply { addView(root) })
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val shizuku = when {
            !ShizukuInput.isRunning() -> "chưa chạy (mở app Shizuku và khởi động)"
            !ShizukuInput.hasPermission() -> "đang chạy, chưa cấp quyền"
            else -> "sẵn sàng ✓"
        }
        status.text = "Quyền hiển thị: ${if (overlay) "đã cấp ✓" else "chưa cấp"}\nShizuku: $shizuku"
    }

    private fun requestShizuku() {
        when {
            !ShizukuInput.isRunning() -> toast("Hãy mở app Shizuku và khởi động nó trước")
            ShizukuInput.hasPermission() -> toast("Đã có quyền Shizuku")
            else -> Shizuku.requestPermission(100)
        }
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) { toast("Cần cấp quyền hiển thị trên ứng dụng khác"); return }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, BubbleService::class.java))
        toast("Đã bật bong bóng. Mở game để dùng.")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

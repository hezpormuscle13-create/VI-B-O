package com.hezpor.otgmapper

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.CheckedTextView
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

/**
 * Màn hình chính kiểu GG Mouse Pro / Panda Mouse Pro:
 * danh sách game đã thêm -> chạm để mở game kèm bong bóng map phím.
 */
class MainActivity : Activity() {

    private class Game(val pkg: String, val label: String, val icon: Drawable)

    private val BG = 0xFF0F1620.toInt()
    private val CARD = 0xFF1B2533.toInt()
    private val ACCENT = 0xFF1E88E5.toInt()

    private lateinit var status: TextView
    private lateinit var fixBox: LinearLayout
    private lateinit var grid: GridView
    private var games = listOf<Game>()

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refresh() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = r.toFloat()
    }

    private fun pill(t: String, f: () -> Unit) = TextView(this).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(9), dp(14), dp(9))
        background = bg(ACCENT, dp(18))
        setOnClickListener { f() }
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(Color.WHITE)
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
        gravity = Gravity.CENTER
        setPadding(0, dp(6), 0, 0)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(24), dp(16), dp(8))
        }

        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(
            TextView(this).apply {
                text = "OTG Mapper"
                textSize = 22f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        )
        head.addView(pill("+ Thêm game") { showAdd() })
        root.addView(head)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFB0BEC5.toInt())
            setPadding(0, dp(10), 0, dp(4))
        }
        root.addView(status)

        fixBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(fixBox)

        grid = GridView(this).apply {
            numColumns = 3
            horizontalSpacing = dp(10)
            verticalSpacing = dp(10)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setSelector(ColorDrawable(Color.TRANSPARENT))
        }
        grid.setOnItemClickListener { _, _, pos, _ ->
            if (pos < games.size) launch(games[pos]) else showAdd()
        }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < games.size) {
                val g = games[pos]
                AlertDialog.Builder(this)
                    .setTitle(g.label)
                    .setItems(arrayOf("Đặt lại bố cục nút", "Xóa khỏi danh sách")) { _, which ->
                        if (which == 0) {
                            Store.reset(this, g.pkg)
                            toast("Đã đặt lại bố cục")
                        } else {
                            Store.removeGame(this, g.pkg)
                            refresh()
                        }
                    }
                    .show()
            }
            true
        }
        root.addView(grid, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = dp(8) })

        root.addView(TextView(this).apply {
            text = "Chạm game để mở kèm bong bóng 🎮 • Giữ game để xóa/đặt lại • Trong game: bong bóng → Sửa nút → kéo nút vào vị trí → Lưu → Map: BẬT • F1 để tạm dừng map"
            textSize = 12f
            setTextColor(0xFF78909C.toInt())
            setPadding(0, dp(8), 0, dp(8))
        })

        setContentView(root)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val running = ShizukuInput.isRunning()
        val perm = ShizukuInput.hasPermission()
        val sz = when {
            !running -> "chưa chạy ✗"
            !perm -> "chưa cấp quyền ✗"
            else -> "sẵn sàng ✓"
        }
        status.text = "Quyền hiển thị: ${if (overlay) "✓" else "✗"}   •   Shizuku: $sz"

        fixBox.removeAllViews()
        fun addFix(v: View) {
            fixBox.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) })
        }
        if (!overlay) addFix(pill("Cấp quyền hiển thị trên ứng dụng khác") { openOverlaySettings() })
        if (!running) addFix(pill("Mở Shizuku để khởi động") { openShizuku() })
        else if (!perm) addFix(pill("Cấp quyền Shizuku cho OTG Mapper") { Shizuku.requestPermission(100) })

        val pm = packageManager
        games = Store.games(this).mapNotNull { pkg ->
            try {
                val ai = pm.getApplicationInfo(pkg, 0)
                Game(pkg, pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai))
            } catch (e: Exception) {
                null
            }
        }
        grid.adapter = Adapter()
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = games.size + 1
        override fun getItem(position: Int): Any = if (position < games.size) games[position] else ""
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(14), dp(8), dp(12))
                background = bg(CARD, dp(14))
            }
            if (position < games.size) {
                val g = games[position]
                card.addView(
                    ImageView(this@MainActivity).apply { setImageDrawable(g.icon) },
                    LinearLayout.LayoutParams(dp(56), dp(56))
                )
                card.addView(label(g.label))
            } else {
                card.addView(
                    TextView(this@MainActivity).apply {
                        text = "+"
                        textSize = 36f
                        setTextColor(ACCENT)
                        gravity = Gravity.CENTER
                    },
                    LinearLayout.LayoutParams(dp(56), dp(56))
                )
                card.addView(label("Thêm game"))
            }
            return card
        }
    }

    // ---------- thêm game ----------

    private fun showAdd() {
        val pm = packageManager
        val have = Store.games(this).toSet()
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName && it.activityInfo.packageName !in have }
            .distinctBy { it.activityInfo.packageName }
            .map { Game(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
        if (apps.isEmpty()) {
            toast("Không còn app nào để thêm")
            return
        }
        val lv = ListView(this)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.adapter = object : ArrayAdapter<String>(
            this, android.R.layout.simple_list_item_multiple_choice, apps.map { it.label }
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as CheckedTextView
                val ic = apps[position].icon
                ic.setBounds(0, 0, dp(36), dp(36))
                v.setCompoundDrawables(ic, null, null, null)
                v.compoundDrawablePadding = dp(12)
                return v
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Chọn game để thêm")
            .setView(lv)
            .setPositiveButton("Thêm") { _, _ ->
                val checked = lv.checkedItemPositions
                val picked = apps.filterIndexed { i, _ -> checked.get(i) }.map { it.pkg }
                Store.addGames(this, picked)
                refresh()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    // ---------- mở game ----------

    private fun launch(g: Game) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Cấp quyền hiển thị trên ứng dụng khác trước")
            openOverlaySettings()
            return
        }
        if (!ShizukuInput.isRunning()) {
            toast("Hãy khởi động Shizuku trước")
            return
        }
        if (!ShizukuInput.hasPermission()) {
            Shizuku.requestPermission(100)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, BubbleService::class.java).putExtra("pkg", g.pkg))
        val li = packageManager.getLaunchIntentForPackage(g.pkg)
        if (li != null) startActivity(li) else toast("Không mở được game này")
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) startActivity(i) else toast("Chưa cài Shizuku. Hãy cài app Shizuku trước.")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

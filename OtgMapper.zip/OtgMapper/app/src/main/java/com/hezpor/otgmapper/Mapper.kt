package com.hezpor.otgmapper

import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import kotlin.math.hypot

/**
 * Biến sự kiện phím/chuột thành chạm.
 * Id ngón tay: 0 = joystick, 1 = camera chuột, 2+ = các nút bấm.
 */
class Mapper(
    private val inj: TouchInjector,
    private val p: Profile,
    private val size: () -> IntArray
) {
    private val h = Handler(Looper.getMainLooper())
    private val held = HashSet<Int>()
    private var prevButtons = 0
    private var camOn = false
    private var cx = 0f
    private var cy = 0f
    private val camIdle = Runnable { camUp() }

    /** Trả về [x px, y px, bán kính px] của nút. */
    private fun px(m: MapItem): FloatArray {
        val s = size()
        return floatArrayOf(m.x * s[0], m.y * s[1], m.r * s[1])
    }

    fun key(code: Int, down: Boolean): Boolean {
        val changed = if (down) held.add(code) else held.remove(code)
        if (!changed) return code != KeyEvent.KEYCODE_BACK // phím lặp
        p.items.forEachIndexed { i, m ->
            if (m.kind == Kind.TAP && m.key == code) {
                val a = px(m)
                if (down) inj.down(2 + i, a[0], a[1]) else inj.up(2 + i)
            }
        }
        joystick()
        return code != KeyEvent.KEYCODE_BACK
    }

    private fun joystick() {
        val j = p.items.firstOrNull { it.kind == Kind.JOYSTICK } ?: return
        val dx = (if (KeyEvent.KEYCODE_D in held) 1 else 0) - (if (KeyEvent.KEYCODE_A in held) 1 else 0)
        val dy = (if (KeyEvent.KEYCODE_S in held) 1 else 0) - (if (KeyEvent.KEYCODE_W in held) 1 else 0)
        if (dx == 0 && dy == 0) { inj.up(0); return }
        val a = px(j)
        val n = if (dx != 0 && dy != 0) 0.7071f else 1f
        inj.down(0, a[0] + dx * n * a[2], a[1] + dy * n * a[2])
    }

    /** dx, dy: độ dịch chuyển thô của chuột; buttons: MotionEvent.buttonState. */
    fun mouse(dx: Float, dy: Float, buttons: Int) {
        val diff = buttons xor prevButtons
        if (diff and 1 != 0) key(MOUSE_LEFT, buttons and 1 != 0)
        if (diff and 2 != 0) key(MOUSE_RIGHT, buttons and 2 != 0)
        if (diff and 4 != 0) key(MOUSE_MIDDLE, buttons and 4 != 0)
        prevButtons = buttons
        if (dx != 0f || dy != 0f) look(dx, dy)
    }

    private fun look(dx: Float, dy: Float) {
        val c = p.items.firstOrNull { it.kind == Kind.CAMERA } ?: return
        val a = px(c)
        if (!camOn) {
            camOn = true; cx = a[0]; cy = a[1]
            inj.down(1, cx, cy)
        }
        cx += dx * p.sens
        cy += dy * p.sens
        if (hypot(cx - a[0], cy - a[1]) > a[2]) {
            // chạm ra ngoài vùng -> nhấc lên rồi đặt lại ở tâm để xoay tiếp
            inj.up(1); cx = a[0]; cy = a[1]; inj.down(1, cx, cy)
        } else {
            inj.move(1, cx, cy)
        }
        h.removeCallbacks(camIdle)
        h.postDelayed(camIdle, 100)
    }

    private fun camUp() {
        if (camOn) { inj.up(1); camOn = false }
    }

    fun releaseAll() {
        h.removeCallbacks(camIdle)
        held.clear()
        prevButtons = 0
        camOn = false
        inj.upAll()
    }
}

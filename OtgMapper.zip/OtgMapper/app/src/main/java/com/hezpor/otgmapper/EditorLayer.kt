package com.hezpor.otgmapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

/**
 * Lớp phủ toàn màn hình để sắp xếp nút (hiện khi bấm "Sửa nút" ở bong bóng).
 * - Kéo để di chuyển, chạm nút "Nút" rồi nhấn phím/click chuột để gán
 * - Giữ lâu để xóa, thanh dưới để thêm / đổi cỡ / chỉnh độ nhạy / lưu
 */
class EditorLayer(
    ctx: Context,
    private val p: Profile,
    private val onDone: (save: Boolean) -> Unit
) : FrameLayout(ctx) {

    private var sel: MapItem? = null
    private var waiting: MapItem? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ui = Handler(Looper.getMainLooper())

    private val hint = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        textSize = 14f
        setBackgroundColor(0xAA000000.toInt())
        setPadding(24, 12, 24, 12)
    }
    private val board = Board(ctx)

    init {
        isFocusableInTouchMode = true
        addView(board, LayoutParams(MATCH_PARENT, MATCH_PARENT))
        addView(hint, LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val bar = LinearLayout(ctx).apply { setBackgroundColor(0xCC000000.toInt()) }
        fun btn(t: String, f: () -> Unit) {
            bar.addView(Button(ctx).apply {
                text = t
                isAllCaps = false
                setOnClickListener { f(); refresh() }
            })
        }
        btn("+ Joystick") { add(Kind.JOYSTICK) }
        btn("+ Camera") { add(Kind.CAMERA) }
        btn("+ Nút") { add(Kind.TAP) }
        btn("+ Bắn") { add(Kind.TAP, MOUSE_LEFT) }
        btn("Nhỏ") { resize(-0.01f) }
        btn("Lớn") { resize(0.01f) }
        btn("Nhạy −") { p.sens = (p.sens - 0.25f).coerceAtLeast(0.25f) }
        btn("Nhạy +") { p.sens = (p.sens + 0.25f).coerceAtMost(6f) }
        btn("Lưu") { onDone(true) }
        btn("Hủy") { onDone(false) }
        addView(
            HorizontalScrollView(ctx).apply { addView(bar) },
            LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM)
        )
        refresh()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        requestFocus()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val w = waiting
        if (w != null && e.action == KeyEvent.ACTION_DOWN) {
            if (e.keyCode != KeyEvent.KEYCODE_BACK) w.key = e.keyCode
            waiting = null
            refresh()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    private fun add(k: Kind, key: Int = -1) {
        if (k != Kind.TAP && p.items.any { it.kind == k }) {
            Toast.makeText(context, "Đã có rồi, kéo nó đi chỗ khác", Toast.LENGTH_SHORT).show()
            return
        }
        val item = when (k) {
            Kind.JOYSTICK -> MapItem(k, 0.17f, 0.70f, 0.12f)
            Kind.CAMERA -> MapItem(k, 0.75f, 0.45f, 0.15f)
            Kind.TAP -> MapItem(k, if (key >= 0) 0.88f else 0.5f, if (key >= 0) 0.72f else 0.5f, 0.06f, key)
        }
        p.items.add(item)
        sel = item
        waiting = if (k == Kind.TAP && key < 0) item else null
    }

    private fun resize(d: Float) {
        sel?.let { it.r = (it.r + d).coerceIn(0.03f, 0.30f) }
    }

    private fun refresh() {
        hint.text = if (waiting != null) "Nhấn 1 phím (hoặc click chuột) để gán cho nút này"
        else "Kéo để di chuyển • Chạm nút để gán phím • Giữ lâu để xóa • Nhạy: %.2f".format(p.sens)
        board.invalidate()
    }

    private inner class Board(ctx: Context) : View(ctx) {
        private var dragging: MapItem? = null
        private var offX = 0f
        private var offY = 0f
        private var startX = 0f
        private var startY = 0f
        private var moved = false
        private val longPress = Runnable {
            dragging?.let {
                p.items.remove(it)
                if (sel === it) sel = null
                dragging = null
                refresh()
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val w = width.toFloat()
            val hh = height.toFloat()
            val w0 = waiting
            if (w0 != null && e.actionMasked == MotionEvent.ACTION_DOWN &&
                e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE
            ) {
                val code = when {
                    e.buttonState and 1 != 0 -> MOUSE_LEFT
                    e.buttonState and 2 != 0 -> MOUSE_RIGHT
                    e.buttonState and 4 != 0 -> MOUSE_MIDDLE
                    else -> -1
                }
                if (code != -1) { w0.key = code; waiting = null; refresh(); return true }
            }
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    waiting = null
                    dragging = p.items.lastOrNull {
                        hypot(e.x - it.x * w, e.y - it.y * hh) <= it.r * hh
                    }
                    sel = dragging
                    dragging?.let {
                        offX = it.x * w - e.x; offY = it.y * hh - e.y
                        startX = e.x; startY = e.y; moved = false
                        ui.postDelayed(longPress, 700)
                    }
                    refresh()
                }
                MotionEvent.ACTION_MOVE -> dragging?.let {
                    if (!moved && hypot(e.x - startX, e.y - startY) > 15f) {
                        moved = true
                        ui.removeCallbacks(longPress)
                    }
                    if (moved) {
                        it.x = ((e.x + offX) / w).coerceIn(0f, 1f)
                        it.y = ((e.y + offY) / hh).coerceIn(0f, 1f)
                        invalidate()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(longPress)
                    val d = dragging
                    if (d != null && !moved && d.kind == Kind.TAP && e.actionMasked == MotionEvent.ACTION_UP) {
                        waiting = d
                    }
                    dragging = null
                    refresh()
                }
            }
            return true
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val hh = height.toFloat()
            c.drawColor(0x99000000.toInt())
            for (m in p.items) {
                val cx = m.x * w
                val cy = m.y * hh
                val r = m.r * hh
                paint.style = Paint.Style.FILL
                paint.color = when (m.kind) {
                    Kind.JOYSTICK -> 0x661E88E5
                    Kind.CAMERA -> 0x66FB8C00
                    Kind.TAP -> 0x6643A047
                }
                c.drawCircle(cx, cy, r, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = if (m === sel) 8f else 3f
                paint.color = if (m === waiting) Color.YELLOW else Color.WHITE
                c.drawCircle(cx, cy, r, paint)
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = (r * 0.4f).coerceIn(24f, 56f)
                val label = when (m.kind) {
                    Kind.JOYSTICK -> "W A S D"
                    Kind.CAMERA -> "Chuột"
                    Kind.TAP -> if (m.key < 0) "?" else keyName(m.key)
                }
                c.drawText(label, cx, cy + paint.textSize / 3, paint)
            }
        }
    }
}

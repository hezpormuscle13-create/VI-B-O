# OTG Mapper (Kotlin + Shizuku)

Map phím/chuột OTG thành cảm ứng cho game Android, có bong bóng nổi để sửa nút ngay trong game.

## Build
- **Android Studio:** File → Open thư mục này → Run (hoặc Build → Build APK).
- **Không có PC:** đẩy thư mục lên GitHub, workflow `.github/workflows/build.yml` tự build, tải APK ở tab Actions → Artifacts.

## Dùng
1. Cài và khởi động **Shizuku** (ADB không dây trong Tùy chọn nhà phát triển).
2. Mở OTG Mapper → cấp quyền hiển thị trên ứng dụng khác + quyền Shizuku → Bật bong bóng.
3. Vào game, chạm bong bóng 🎮:
   - **Sửa nút:** kéo joystick (WASD), vùng camera (chuột), nút bấm; chạm nút rồi nhấn phím/click chuột để gán; giữ lâu để xóa; Lưu.
   - **Map: BẬT:** chơi bằng phím/chuột OTG. **F1** để tạm dừng/tiếp tục.

## Cách hoạt động
- `BubbleService`: bong bóng + menu (cửa sổ overlay).
- `EditorLayer`: màn hình chỉnh nút, lưu profile JSON (tọa độ theo tỉ lệ màn hình).
- `InputOverlay`: cửa sổ 1x1 px nhận phím OTG và khóa chuột (pointer capture), không chặn cảm ứng.
- `Mapper`: phím/chuột → chạm ảo (joystick, camera, nút bấm).
- `TouchInjector` + `ShizukuInput`: tạo MotionEvent đa điểm và inject với quyền shell.

## Lưu ý / việc tiếp theo
- Mã chưa được test trên máy thật; cần thử trên thiết bị và chỉnh theo từng game.
- Một số game tạm dừng khi mất focus cửa sổ; nếu gặp, cần đổi cách nhận phím.
- Mở rộng: profile theo từng game (UsageStats để tự đổi), cuộn chuột, phím mũi tên, chỉnh phím F1.
